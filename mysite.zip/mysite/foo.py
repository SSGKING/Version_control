def reciprocal(x):
    return 1/x
def isPositive(n):
    if n > 0:
        return True
    else:
        return False